<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TitleSituation extends Model
{
    protected $fillable = [
        'titleSituation',
         'description',
    ];
}
